/*
 *    ______   __                  __  __
 *   /      \ /  |                /  |/  |
 *  /$$$$$$  |$$ |____    ______  $$ |$$ |  ______   _______    ______    ______
 *  $$ |  $$/ $$      \  /      \ $$ |$$ | /      \ /       \  /      \  /      \
 *  $$ |      $$$$$$$  | $$$$$$  |$$ |$$ |/$$$$$$  |$$$$$$$  |/$$$$$$  |/$$$$$$  |
 *  $$ |   __ $$ |  $$ | /    $$ |$$ |$$ |$$    $$ |$$ |  $$ |$$ |  $$ |$$    $$ |
 *  $$ \__/  |$$ |  $$ |/$$$$$$$ |$$ |$$ |$$$$$$$$/ $$ |  $$ |$$ \__$$ |$$$$$$$$/
 *  $$    $$/ $$ |  $$ |$$    $$ |$$ |$$ |$$       |$$ |  $$ |$$    $$ |$$       |
 *   $$$$$$/  $$/   $$/  $$$$$$$/ $$/ $$/  $$$$$$$/ $$/   $$/  $$$$$$$ | $$$$$$$/
 *                                                            /  \__$$ |
 *                                                            $$    $$/
 *                                                             $$$$$$/
 *
 *  Send your finished challenge to askjag07@gmail.com. The most creative projects will be showcased towards the end of the course.
 *
 *  GOALS
 *  1. Improve the chatbot from the classwork with your own creativity. Good luck!
 *
 *
 *
 *  INSTRUCTIONS
 *  Refer to the code from the the classwork. If you need any help, call me.
 */
